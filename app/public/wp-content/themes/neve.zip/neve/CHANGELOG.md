
 ### v1.0.4 - 2018-10-04 
 **Changes:** 
 * Two new prebuilt demos
* RTL compatibility
* Fixed styling issues
* Basic WooCommerce support
* Added Git hooks
 
 ### v1.0.3 - 2018-09-24 
 **Changes:** 
 * Add proper Elementor Header and Footer support
* Fixed warning caused by forgotten "var_dump" in page / post metabox handler
 
 ### v1.0.2 - 2018-09-07 
 **Changes:** 
 * Demo data for Neve 2018 template
 
 ### v1.0.1 - 2018-09-07 
 **Changes:** 
 * Updated description and screenshot
 
 ### v1.0.0 - 2018-09-06 
 **Changes:** 
 * Lowercase file names.
 
